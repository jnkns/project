<?php

    require "db.php";
    unset($_SESSION['users']);
    header('Location: ./index.php');

 ?>
